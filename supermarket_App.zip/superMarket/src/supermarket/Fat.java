package supermarket;

public enum Fat {
    FULLCREAM, HALFCREAM, SKIMMED;
}
