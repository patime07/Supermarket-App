package supermarket;

public enum SugarLevel {
    LIGHT, ZERO, ADDED_SUGAR, NO_ADDED_SUGAR;
}
